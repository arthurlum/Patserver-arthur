const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');

const app = express();
app.use(bodyParser.json());

const conn = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'tiket_wisata',
});

conn.connect(function(err){
    if (err) throw err;
    console.log("MySQL connected.....");
});

//Login
app.post('/login', function(req, res) {
    console.log("POST request /login");
    let username = req.body.username;
    let password = req.body.password;
    let sql = "SELECT * FROM user WHERE username = ? AND password = ?";
    let query = conn.query(sql, [username, password], (err, result) => {
        if (err) {
            console.error(err);
            res.status(500).send("Terjadi kesalahan server");
            return;
        }
        
        if (result.length > 0) {
            console.log("Login Berhasil");
            res.status(200).send("Login Berhasil");
        } else {
            console.log("Login Gagal");
            res.status(401).send("Login Gagal");
        }
    });
});

//Tambah Paket
app.post('/tambahpaket', function(req, res) {
    console.log("POST request /tambahpaket");
    
    let username = req.body.username;
    let password = req.body.password;
    let harga_paket = req.body.harga_paket;
    let jenis_trip = req.body.jenis_trip;
    let list_wisata = req.body.list_wisata;


    let sql = "INSERT INTO paket (username, password, harga_paket, jenis_trip, list_wisata) VALUES (?, ?, ?, ?, ?)";
    
    let query = conn.query(sql, [username, password, harga_paket, jenis_trip, list_wisata], (err, result) => {
        if (err) {
            console.error(err);
            res.status(500).send("Terjadi kesalahan server");
            return;
        }
        
        if (result.affectedRows > 0) {
            console.log("Tambah Paket Berhasil");
            res.status(200).send("Tambah Paket Berhasil");
        } else {
            console.log("Tambah Paket Gagal");
            res.status(500).send("Tambah Paket Gagal");
        }
    });
});

//Edit Data Paket
app.put('/editpaket/:id', function(req, res) {
    console.log("PUT request /editpaket");
    
    let paketid = req.params.id;
    
    let username = req.body.username;
    let password = req.body.password;
    let harga_paket = req.body.harga_paket;
    let jenis_trip = req.body.jenis_trip;
    let list_wisata = req.body.list_wisata;


    let sql = "UPDATE paket SET username = ?, password = ?, harga_paket = ?, jenis_trip = ?, list_wisata = ? WHERE id = ?";
    
    let query = conn.query(sql, [username, password, harga_paket, jenis_trip, list_wisata, paketid], (err, result) => {
        if (err) {
            console.error(err);
            res.status(500).send("Terjadi kesalahan server");
            return;
        }
        
        if (result.affectedRows > 0) {
            console.log("Edit Paket Berhasil");
            res.status(200).send("Edit Paket Berhasil");
        } else {
            console.log("Edit Paket Gagal");
            res.status(500).send("Edit Paket Gagal");
        }
    });
});

//Hapus Paket Wisata
app.delete('/hapuspaket/:id', function(req, res) {
    console.log("DELETE request /hapuspaket/:id");

    let paketId = req.params.id;

    let sql = "DELETE FROM paket WHERE id = ?";
    
    let query = conn.query(sql, [paketId], (err, result) => {
        if (err) {
            console.error(err);
            res.status(500).send("Terjadi kesalahan server");
            return;
        }
        
        if (result.affectedRows > 0) {
            console.log("Hapus Paket Berhasil");
            res.status(200).send("Hapus Paket Berhasil");
        } else {
            console.log("Data tidak ditemukan atau sudah dihapus.");
            res.status(500).send("Data tidak ditemukan atau sudah dihapus.");
        }
    });
});


//Tambah Pesanan
app.post('/tambahpesan', function(req, res) {
    console.log("POST request /tambahpesan");
    
    let nama = req.body.nama;
    let email = req.body.email;
    let tanggal_trip = req.body.tanggal_trip;
    let jumlah_orang = req.body.jumlah_orang;
    let pilih_paket = req.body.pilih_paket;
    let usia = req.body.usia;

    let sql = "INSERT INTO pesan (nama, email, tanggal_trip, jumlah_orang, pilih_paket, usia) VALUES (?, ?, ?, ?, ?, ?)";
    
    let query = conn.query(sql, [nama, email, tanggal_trip, jumlah_orang, pilih_paket, usia], (err, result) => {
        if (err) {
            console.error(err);
            res.status(500).send("Gagal Pesan Paket");
            return;
        }
        
        if (result.affectedRows > 0) {
            console.log("Berhasil Pesan Paket");
            res.status(200).send("Berhasil Pesan Paket");
        } else {
            console.log("Gagal Pesan Paket");
            res.status(500).send("Gagal Pesan Paket");
        }
    });
});


//List Daftar Paket Wisata
app.get('/daftarpaket', function(req, res) {
    console.log("GET request /daftarpaket");

    let sql = "SELECT * FROM paket";
    
    conn.query(sql, (err, result) => {
        if (err) {
            console.error(err);
            res.status(500).send("Terjadi kesalahan server");
            return;
        }
        
        if (result.length > 0) {
            console.log("Daftar Paket Wisata Ditemukan");
            res.status(200).json(result);
        } else {
            console.log("Daftar Paket Wisata Kosong");
            res.status(404).send("Daftar Paket Wisata Kosong");
        }
    });
});

app.get('/daftarpesanan', function(req, res) {
    console.log("GET request /daftarpaket");

    let sql = "SELECT * FROM pesan";
    
    conn.query(sql, (err, result) => {
        if (err) {
            console.error(err);
            res.status(500).send("Terjadi kesalahan server");
            return;
        }
        
        if (result.length > 0) {
            console.log("Daftar Pesanan Wisata Ditemukan");
            res.status(200).json(result);
        } else {
            console.log("Daftar Pesanan Wisata Kosong");
            res.status(404).send("Daftar Paket Wisata Kosong");
        }
    });
});




var server = app.listen(8000, function() {
    console.log("Server API berjalan di port 8000");
});
